#ifndef GLOBALS_H
#define GLOBALS_H

#include "Game.h"
#include <vector>

using namespace std;

static vector<Game*> games;

#endif