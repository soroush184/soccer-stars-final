#ifndef GAMESTATE_H
#define GAMESTATE_H

enum class GameState {
    WAITING_FOR_PLAYER_2,
    TURN_PLAYER_1,
    TURN_PLAYER_2,
};

#endif