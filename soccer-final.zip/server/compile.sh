#!/bin/bash

g++ server.cpp Game.cpp Player.cpp Logger.cpp  -o server